using System;
using System.Windows.Forms;

namespace MyWinFormsApp
{
    public partial class Form1 : Form
    {
        // Based Char
        public Form1()
        {
            InitializeComponent();
        }

        private void compileButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;

            // Lexer
            string tokens = Lexer(input);
            lexerTextBox.Text = tokens;

            // Parser
            TreeNode parseTree = Parser(input);
            parserTreeView.Nodes.Clear();
            parserTreeView.Nodes.Add(parseTree);

            // Semantic Analysis
            string semanticAnalysis = SemanticAnalyzer(input);
            semanticTextBox.Text = semanticAnalysis;

            // Code Optimization
            string optimizedCode = CodeOptimization(input);
            optimizedTextBox.Text = optimizedCode;

            // Code Generation
            string generatedCode = CodeGeneration(input);
            generatedCodeTextBox.Text = generatedCode;
        }

        private string Lexer(string input)
        {
            // Lexer for grammar based-num -> num basechar
            string tokens = "";
            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    tokens += "digit ";
                }
                else if (c == 'o' || c == 'd')
                {
                    tokens += "basechar ";
                }
                else if (c == ' ')
                {
                    continue;  // Ignore spaces
                }
                else
                {
                    tokens += $"Invalid character: {c}";
                    break;
                }
            }
            return tokens;
        }

        private TreeNode Parser(string input)
        {
            // Parse the input according to the grammar
            TreeNode root = new TreeNode("based-num");

            // Split input into num and basechar
            var parts = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 2)
            {
                TreeNode numNode = new TreeNode("num");
                foreach (var part in parts[0])
                {
                    TreeNode digitNode = new TreeNode("digit: " + part);
                    numNode.Nodes.Add(digitNode);
                }

                TreeNode baseCharNode = new TreeNode("basechar: " + parts[1]);

                root.Nodes.Add(numNode);
                root.Nodes.Add(baseCharNode);
            }
            else
            {
                root.Nodes.Add(new TreeNode("Invalid input"));
            }

            return root;
        }

        private string SemanticAnalyzer(string input)
        {
            // Semantic analysis for checking validity of basechar (either 'o' or 'd')
            var parts = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length != 2)
            {
                return "Semantic Error: Invalid input format.";
            }

            string basechar = parts[1];
            if (basechar != "o" && basechar != "d")
            {
                return "Semantic Error: basechar must be 'o' or 'd'.";
            }

            return "Semantic Analysis: Input is valid.";
        }

        private string CodeOptimization(string input)
        {
            // Split the input into `num` and `basechar`
            string[] parts = input.Split(' ');
            if (parts.Length != 2) return "Error: Invalid based-num format.";

            string num = parts[0].TrimStart('0'); // Remove leading zeros
            string basechar = parts[1].Trim();

            // Validate basechar
            if (basechar != "o" && basechar != "d")
            {
                return "Error: Invalid base character. Use 'o' for octal or 'd' for decimal.";
            }

            // Validate num against the base
            if (basechar == "o")
            {
                // Check if the number contains invalid digits for octal
                foreach (char c in num)
                {
                    if (c < '0' || c > '7')
                        return $"Error: Invalid digit '{c}' in octal number.";
                }
            }
            else if (basechar == "d")
            {
                // Decimal numbers can have any digit from 0 to 9
                foreach (char c in num)
                {
                    if (c < '0' || c > '9')
                        return $"Error: Invalid digit '{c}' in decimal number.";
                }
            }

            return $"Optimized Based-Num: {num} {basechar}";
        }

    private string CodeGeneration(string input)
    {
        // Split the input into `num` and `basechar`
        string[] parts = input.Split(' ');
        if (parts.Length != 2) return "Error: Invalid based-num format.";

        string num = parts[0].TrimStart('0'); // Remove leading zeros
        string basechar = parts[1].Trim();
        string assemblyCode = "";

        // Generate assembly code based on the base
        if (basechar == "o")
        {
            // Convert octal to decimal and load into AX
            int decimalValue = Convert.ToInt32(num, 8); // Convert octal to decimal
            assemblyCode += $"MOV AX, {decimalValue} ; Load octal value (converted to decimal)\n";
        }
        else if (basechar == "d")
        {
            // Load decimal directly into AX
            assemblyCode += $"MOV AX, {num} ; Load decimal value\n";
        }
        else
        {
            return "Error: Invalid base character.";
        }

        return "Generated Assembly Code:\n" + assemblyCode;
    }
    }
}
