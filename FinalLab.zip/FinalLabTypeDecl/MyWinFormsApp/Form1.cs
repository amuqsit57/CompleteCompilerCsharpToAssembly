using System;
using System.Windows.Forms;

    namespace MyWinFormsApp
    {

    public partial class Form1 : Form
    {

        // type declaration
        public Form1()
        {
            InitializeComponent();
        }

        private void compileButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;

            // Lexer
            string tokens = Lexer(input);
            lexerTextBox.Text = tokens;

            // Parser
            TreeNode parseTree = Parser(input);
            parserTreeView.Nodes.Clear();
            parserTreeView.Nodes.Add(parseTree);

            // Semantic Analysis
            string semanticAnalysis = SemanticAnalyzer(input);
            semanticTextBox.Text = semanticAnalysis;

            // Code Optimization
            string optimizedCode = CodeOptimization(input);
            optimizedTextBox.Text = optimizedCode;

            // Code Generation
            string generatedCode = CodeGeneration(input);
            generatedCodeTextBox.Text = generatedCode;
        }

        private string Lexer(string input)
        {
            // Simulated lexer for the grammar "decl -> var-list : type"
            // Tokenize the input string
            return "Tokens: [var-list, :, type]";
        }

        private TreeNode Parser(string input)
        {
            // Simulate a parser that generates a parse tree for the grammar
            TreeNode root = new TreeNode("decl");

            TreeNode varListNode = new TreeNode("var-list");
            varListNode.Nodes.Add("id");
            varListNode.Nodes.Add(", id");

            TreeNode typeNode = new TreeNode("type");
            typeNode.Nodes.Add("integer");

            root.Nodes.Add(varListNode);
            root.Nodes.Add(":");
            root.Nodes.Add(typeNode);

            return root;
        }

        private string SemanticAnalyzer(string input)
        {
            // Simulate semantic analysis
            return "Semantic Analysis: Variable list and type are consistent.";
        }

        private string CodeOptimization(string input)
        {
            // Parse the declaration to eliminate redundant variables.
            string[] parts = input.Split(':');
            if (parts.Length != 2) return "Error: Invalid declaration.";

            string varList = parts[0].Trim();
            string type = parts[1].Trim();
            HashSet<string> uniqueVars = new HashSet<string>();

            // Split variable list and remove duplicates
            string[] vars = varList.Split(',');
            foreach (string var in vars)
            {
                uniqueVars.Add(var.Trim());
            }

            string optimizedVarList = string.Join(", ", uniqueVars);
            return $"Optimized Declaration: {optimizedVarList} : {type}";
        }


        private string CodeGeneration(string input)
        {
            // Parse the declaration to generate assembly code.
            string[] parts = input.Split(':');
            if (parts.Length != 2) return "Error: Invalid declaration.";

            string varList = parts[0].Trim();
            string type = parts[1].Trim();
            string assemblyCode = "";

            // Determine the memory allocation based on the type.
            string directive = type == "integer" ? "DWORD" : "REAL4";

            // Generate assembly declarations for each variable.
            string[] vars = varList.Split(',');
            foreach (string var in vars)
            {
                string trimmedVar = var.Trim();
                assemblyCode += $"{trimmedVar} {directive} ?\n";
            }

            return "Generated Assembly Code:\n" + assemblyCode;
        }

    }
}
