using System;
using System.Text;
using System.Windows.Forms;

namespace MyWinFormsApp
{
    public partial class Form1 : Form
    {
        // Arithmetic OPs
        public Form1()
        {
            InitializeComponent();
        }

        private void compileButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;

            // Lexer
            string tokens = Lexer(input);
            lexerTextBox.Text = tokens;

            // Parser
            TreeNode parseTree = Parser(input);
            parserTreeView.Nodes.Clear();
            parserTreeView.Nodes.Add(parseTree);

            // Semantic Analysis
            string semanticAnalysis = SemanticAnalyzer(input);
            semanticTextBox.Text = semanticAnalysis;

            // Code Optimization
            string optimizedCode = CodeOptimization(input);
            optimizedTextBox.Text = optimizedCode;

            // Code Generation
            string generatedCode = CodeGeneration(input);
            generatedCodeTextBox.Text = generatedCode;
        }

        private string Lexer(string input)
        {
            // Lexer for the given grammar
            string tokens = "";
            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    tokens += "number ";
                }
                else if (c == '+' || c == '-' || c == '*' || c == '(' || c == ')')
                {
                    tokens += $"{c} ";
                }
                else if (c == ' ')
                {
                    continue;  // Ignore spaces
                }
                else
                {
                    tokens += $"Invalid character: {c} ";
                    break;
                }
            }
            return tokens;
        }

        private TreeNode Parser(string input)
        {
            // Parse the input according to the grammar
            TreeNode root = new TreeNode("exp");

            // Split input into tokens for parsing
            var tokens = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int index = 0;

            // Parse the expression (exp -> term exp')
            root.Nodes.Add(ParseExp(tokens, ref index));

            return root;
        }

        private TreeNode ParseExp(string[] tokens, ref int index)
        {
            // exp -> term exp'
            TreeNode expNode = new TreeNode("exp");

            // Parse term
            expNode.Nodes.Add(ParseTerm(tokens, ref index));

            // Parse exp' (recursive part)
            expNode.Nodes.Add(ParseExpPrime(tokens, ref index));

            return expNode;
        }

        private TreeNode ParseTerm(string[] tokens, ref int index)
        {
            // term -> factor term'
            TreeNode termNode = new TreeNode("term");
            termNode.Nodes.Add(ParseFactor(tokens, ref index));
            termNode.Nodes.Add(ParseTermPrime(tokens, ref index));
            return termNode;
        }

        private TreeNode ParseTermPrime(string[] tokens, ref int index)
        {
            // term' -> * factor term' | ε
            TreeNode termPrimeNode = new TreeNode("term'");
            if (index < tokens.Length && tokens[index] == "*")
            {
                termPrimeNode.Nodes.Add(new TreeNode("*"));
                index++;
                termPrimeNode.Nodes.Add(ParseFactor(tokens, ref index));
                termPrimeNode.Nodes.Add(ParseTermPrime(tokens, ref index));
            }
            return termPrimeNode;
        }

        private TreeNode ParseFactor(string[] tokens, ref int index)
        {
            // factor -> (exp) | number
            TreeNode factorNode = new TreeNode("factor");
            if (tokens[index] == "(")
            {
                factorNode.Nodes.Add(new TreeNode("("));
                index++;
                factorNode.Nodes.Add(ParseExp(tokens, ref index));
                if (tokens[index] == ")")
                {
                    factorNode.Nodes.Add(new TreeNode(")"));
                    index++;
                }
            }
            else if (char.IsDigit(tokens[index][0]))
            {
                factorNode.Nodes.Add(new TreeNode($"number: {tokens[index]}"));
                index++;
            }
            return factorNode;
        }

        private TreeNode ParseExpPrime(string[] tokens, ref int index)
        {
            // exp' -> + term exp' | - term exp' | ε
            TreeNode expPrimeNode = new TreeNode("exp'");
            if (index < tokens.Length && (tokens[index] == "+" || tokens[index] == "-"))
            {
                string operatorSymbol = tokens[index];
                expPrimeNode.Nodes.Add(new TreeNode(operatorSymbol));
                index++;
                expPrimeNode.Nodes.Add(ParseTerm(tokens, ref index));
                expPrimeNode.Nodes.Add(ParseExpPrime(tokens, ref index));
            }
            return expPrimeNode;
        }

        private string SemanticAnalyzer(string input)
        {
            // Semantic analysis for checking valid syntax (e.g., balanced parentheses)
            int openParenthesesCount = 0;
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == '(')
                {
                    openParenthesesCount++;
                }
                else if (input[i] == ')')
                {
                    openParenthesesCount--;
                }
            }

            if (openParenthesesCount != 0)
            {
                return "Semantic Error: Unmatched parentheses.";
            }

            return "Semantic Analysis: Input is valid.";
        }

        private string CodeOptimization(string input)
        {
            // Parse and optimize the expression
            try
            {
                var optimizedExpression = SimplifyExpression(input);
                return $"Optimized Expression: {optimizedExpression}";
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        // Simplify constant expressions
        private string SimplifyExpression(string input)
        {
            // Evaluate constant sub-expressions using DataTable (or similar)
            System.Data.DataTable table = new System.Data.DataTable();
            string simplified = table.Compute(input, "").ToString();
            return simplified;
        }


        private string CodeGeneration(string input)
        {
            try
            {
                // Generate assembly code for the expression
                string assemblyCode = GenerateAssembly(input);
                return "Generated Assembly Code:\n" + assemblyCode;
            }
            catch (Exception ex)
            {
                return $"Error: {ex.Message}";
            }
        }

        // Generate assembly code using a stack-based approach
        private string GenerateAssembly(string input)
        {
            Stack<string> stack = new Stack<string>();
            StringBuilder assemblyCode = new StringBuilder();

            // Tokenize and process the input
            string[] tokens = Tokenize(input);
            foreach (string token in tokens)
            {
                if (int.TryParse(token, out int number))
                {
                    // Push numbers to the stack
                    stack.Push(number.ToString());
                    assemblyCode.AppendLine($"PUSH {number}");
                }
                else if (token == "+" || token == "-" || token == "*")
                {
                    // Pop two operands from the stack
                    string operand2 = stack.Pop();
                    string operand1 = stack.Pop();

                    // Generate assembly for the operation
                    assemblyCode.AppendLine($"POP AX ; Load first operand");
                    assemblyCode.AppendLine($"POP BX ; Load second operand");

                    if (token == "+")
                    {
                        assemblyCode.AppendLine("ADD AX, BX ; Perform addition");
                    }
                    else if (token == "-")
                    {
                        assemblyCode.AppendLine("SUB AX, BX ; Perform subtraction");
                    }
                    else if (token == "*")
                    {
                        assemblyCode.AppendLine("MUL BX ; Perform multiplication");
                    }

                    // Push the result back to the stack
                    stack.Push("AX");
                    assemblyCode.AppendLine("PUSH AX ; Push result back to stack");
                }
                else
                {
                    throw new Exception($"Unexpected token: {token}");
                }
            }

            return assemblyCode.ToString();
        }

        // Tokenize the input expression
        private string[] Tokenize(string input)
        {
            return input.Split(new char[] { ' ', '+', '-', '*', '(', ')' }, StringSplitOptions.RemoveEmptyEntries);
        }

    }
}
