﻿    namespace MyWinFormsApp
    {
    partial class Form1
    {

      
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.inputTextBox = new System.Windows.Forms.TextBox();
            this.lexerTextBox = new System.Windows.Forms.TextBox();
            this.parserTreeView = new System.Windows.Forms.TreeView();
            this.semanticTextBox = new System.Windows.Forms.TextBox();
            this.optimizedTextBox = new System.Windows.Forms.TextBox();
            this.generatedCodeTextBox = new System.Windows.Forms.TextBox();
            this.compileButton = new System.Windows.Forms.Button();

            this.SuspendLayout();

            // inputTextBox
            this.inputTextBox.Location = new System.Drawing.Point(12, 12);
            this.inputTextBox.Multiline = true;
            this.inputTextBox.Name = "inputTextBox";
            this.inputTextBox.Size = new System.Drawing.Size(300, 50);
            this.inputTextBox.TabIndex = 0;
            this.inputTextBox.Text = "Enter code here...";

            // lexerTextBox
            this.lexerTextBox.Location = new System.Drawing.Point(12, 80);
            this.lexerTextBox.Multiline = true;
            this.lexerTextBox.Name = "lexerTextBox";
            this.lexerTextBox.ReadOnly = true;
            this.lexerTextBox.Size = new System.Drawing.Size(300, 100);
            this.lexerTextBox.TabIndex = 1;

            // parserTreeView
            this.parserTreeView.Location = new System.Drawing.Point(330, 12);
            this.parserTreeView.Name = "parserTreeView";
            this.parserTreeView.Size = new System.Drawing.Size(300, 168);
            this.parserTreeView.TabIndex = 2;

            // semanticTextBox
            this.semanticTextBox.Location = new System.Drawing.Point(12, 200);
            this.semanticTextBox.Multiline = true;
            this.semanticTextBox.Name = "semanticTextBox";
            this.semanticTextBox.ReadOnly = true;
            this.semanticTextBox.Size = new System.Drawing.Size(300, 100);
            this.semanticTextBox.TabIndex = 3;

            // optimizedTextBox
            this.optimizedTextBox.Location = new System.Drawing.Point(330, 200);
            this.optimizedTextBox.Multiline = true;
            this.optimizedTextBox.Name = "optimizedTextBox";
            this.optimizedTextBox.ReadOnly = true;
            this.optimizedTextBox.Size = new System.Drawing.Size(300, 100);
            this.optimizedTextBox.TabIndex = 4;

            // generatedCodeTextBox
            this.generatedCodeTextBox.Location = new System.Drawing.Point(12, 320);
            this.generatedCodeTextBox.Multiline = true;
            this.generatedCodeTextBox.Name = "generatedCodeTextBox";
            this.generatedCodeTextBox.ReadOnly = true;
            this.generatedCodeTextBox.Size = new System.Drawing.Size(618, 100);
            this.generatedCodeTextBox.TabIndex = 5;

            // compileButton
            this.compileButton.Location = new System.Drawing.Point(12, 440);
            this.compileButton.Name = "compileButton";
            this.compileButton.Size = new System.Drawing.Size(100, 30);
            this.compileButton.TabIndex = 6;
            this.compileButton.Text = "Compile";
            this.compileButton.UseVisualStyleBackColor = true;
            this.compileButton.Click += new System.EventHandler(this.compileButton_Click);

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 485);
            this.Controls.Add(this.inputTextBox);
            this.Controls.Add(this.lexerTextBox);
            this.Controls.Add(this.parserTreeView);
            this.Controls.Add(this.semanticTextBox);
            this.Controls.Add(this.optimizedTextBox);
            this.Controls.Add(this.generatedCodeTextBox);
            this.Controls.Add(this.compileButton);
            this.Name = "Form1";
            this.Text = "Compiler";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.TextBox inputTextBox;
        private System.Windows.Forms.TextBox lexerTextBox;
        private System.Windows.Forms.TreeView parserTreeView;
        private System.Windows.Forms.TextBox semanticTextBox;
        private System.Windows.Forms.TextBox optimizedTextBox;
        private System.Windows.Forms.TextBox generatedCodeTextBox;
        private System.Windows.Forms.Button compileButton;
    }
}