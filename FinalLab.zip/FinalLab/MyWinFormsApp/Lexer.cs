public class Lexer
{
    private readonly string input;
    private int position;

    public Lexer(string input)
    {
        this.input = input;
        this.position = 0;
    }

    public char Peek() => position < input.Length ? input[position] : '\0';

    public char Next()
    {
        return position < input.Length ? input[position++] : '\0';
    }

    public Token GetNextToken()
    {
        while (char.IsWhiteSpace(Peek())) Next();

        char current = Peek();
        if (char.IsDigit(current))
        {
            string number = "";
            while (char.IsDigit(Peek()) || Peek() == '.')
            {
                number += Next();
            }
            return new Token("NUM", number);
        }

        if (current == '\0')
            return new Token("EOF", "");

        throw new Exception("Invalid character");
    }
}

public record Token(string Type, string Value);
