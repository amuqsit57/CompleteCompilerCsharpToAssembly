public class SemanticAnalyzer
{
    private readonly Node parseTree;

    public SemanticAnalyzer(Node parseTree)
    {
        this.parseTree = parseTree;
    }

    public void Analyze()
    {
        if (!AnalyzeNode(parseTree))
            throw new Exception("Semantic analysis failed");
    }

    private bool AnalyzeNode(Node node)
    {
        if (node.Type == "NUM")
        {
            return decimal.TryParse(node.Value, out _);
        }

        if (node.Type == "DNUM")
        {
            return AnalyzeNode(node.Left) && AnalyzeNode(node.Right);
        }

        return false;
    }
}
