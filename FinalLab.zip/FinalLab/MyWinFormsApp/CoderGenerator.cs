public class CodeGenerator
{
    private readonly Node optimizedTree;

    public CodeGenerator(Node optimizedTree)
    {
        this.optimizedTree = optimizedTree;
    }

    public string GenerateCode()
    {
        return GenerateNodeCode(optimizedTree);
    }

    private string GenerateNodeCode(Node node)
    {
        if (node.Type == "NUM")
        {
            return node.Value;
        }

        if (node.Type == "DNUM")
        {
            return $"{GenerateNodeCode(node.Left)}.{GenerateNodeCode(node.Right)}";
        }

        return "";
    }
}
