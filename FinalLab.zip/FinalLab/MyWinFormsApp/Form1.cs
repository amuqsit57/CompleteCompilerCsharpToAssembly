using System;
using System.Text;
using System.Windows.Forms;

    namespace MyWinFormsApp
    {
    public partial class Form1 : Form
    {
        // for decimal number
        public Form1()
        {
            InitializeComponent();
        }

        private void compileButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;
            // Lexer
            string tokens = Lexer(input);
            lexerTextBox.Text = tokens;

            // Parser
            TreeNode parseTree = Parser(input);
            parserTreeView.Nodes.Clear();
            parserTreeView.Nodes.Add(parseTree);

            // Semantic Analysis
            string semanticAnalysis = SemanticAnalyzer(input);
            semanticTextBox.Text = semanticAnalysis;

            // Code Optimization
            string optimizedCode = CodeOptimization(input);
            optimizedTextBox.Text = optimizedCode;

            // Code Generation
            string generatedCode = CodeGeneration(input);
            generatedCodeTextBox.Text = generatedCode;
        }

        private string Lexer(string input)
        {
            // Simulate a lexer that identifies tokens
            return "Tokens: [NUM, '.', NUM]";
        }

        private TreeNode Parser(string input)
        {
            // Simulate a parser that generates a parsing tree
            TreeNode root = new TreeNode("dnum");
            root.Nodes.Add("num");
            root.Nodes.Add(".");
            root.Nodes.Add("num");
            return root;
        }

        private string SemanticAnalyzer(string input)
        {
            // Simulate semantic analysis
            return "Semantic Analysis: Valid decimal number";
        }

        private string CodeOptimization(string input)
        {
            // Split the input into two parts (integer and fractional)
            string[] parts = input.Split('.');
            if (parts.Length != 2)
                return "Error: Invalid dnum format. Expected format: num.num";

            string integerPart = parts[0].TrimStart('0'); // Remove leading zeros from integer part
            string fractionalPart = parts[1].TrimEnd('0'); // Remove trailing zeros from fractional part

            // If empty after trimming, replace with "0"
            if (string.IsNullOrEmpty(integerPart)) integerPart = "0";
            if (string.IsNullOrEmpty(fractionalPart)) fractionalPart = "0";

            return $"Optimized Decimal Number: {integerPart}.{fractionalPart}";
        }


        private string CodeGeneration(string input)
        {
            // Split the input into two parts (integer and fractional)
            string[] parts = input.Split('.');
            if (parts.Length != 2)
                return "Error: Invalid dnum format. Expected format: num.num";

            string integerPart = parts[0];
            string fractionalPart = parts[1];

            // Generate assembly code
            StringBuilder assemblyCode = new StringBuilder();

            // Load integer part into AX
            assemblyCode.AppendLine($"MOV AX, {integerPart} ; Load integer part into AX");

            // Load fractional part into BX
            assemblyCode.AppendLine($"MOV BX, {fractionalPart} ; Load fractional part into BX");

            return "Generated Assembly Code:\n" + assemblyCode.ToString();
        }

    }
}
