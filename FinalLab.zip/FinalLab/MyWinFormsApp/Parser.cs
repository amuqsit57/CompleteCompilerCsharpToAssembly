public class Parser
{
    private readonly Lexer lexer;
    private Token currentToken;

    public Parser(Lexer lexer)
    {
        this.lexer = lexer;
        this.currentToken = lexer.GetNextToken();
    }

    private void Consume(string type)
    {
        if (currentToken.Type == type)
            currentToken = lexer.GetNextToken();
        else
            throw new Exception($"Unexpected token: {currentToken.Type}, expected: {type}");
    }

    public Node Parse()
    {
        Node result = ParseDnum();
        if (currentToken.Type != "EOF")
            throw new Exception("Extra input after valid expression");
        return result;
    }

    private Node ParseDnum()
    {
        Node left = ParseNum();
        if (currentToken.Type == "NUM" && currentToken.Value.Contains("."))
        {
            Node right = ParseNum();
            return new Node("DNUM", left, right);
        }
        return left;
    }

    private Node ParseNum()
    {
        Token token = currentToken;
        Consume("NUM");
        return new Node("NUM", token.Value);
    }
}

public class Node
{
    public string Type { get; }
    public string Value { get; }
    public Node Left { get; }
    public Node Right { get; }

    // Constructor for nodes with children
    public Node(string type, Node left = null, Node right = null)
    {
        Type = type;
        Left = left;
        Right = right;
    }

    // Constructor for leaf nodes
    public Node(string type, string value)
    {
        Type = type;
        Value = value;
    }
}
