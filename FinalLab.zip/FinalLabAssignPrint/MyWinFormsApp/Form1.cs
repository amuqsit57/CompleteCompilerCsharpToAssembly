using System;
using System.Windows.Forms;

namespace MyWinFormsApp
{
    public partial class Form1 : Form
    {
        // PRint And Assign
        public Form1()
        {
            InitializeComponent();
        }

        private void compileButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text;

            // Lexer
            string tokens = Lexer(input);
            lexerTextBox.Text = tokens;

            // Parser
            TreeNode parseTree = Parser(input);
            parserTreeView.Nodes.Clear();
            parserTreeView.Nodes.Add(parseTree);

            // Semantic Analysis
            string semanticAnalysis = SemanticAnalyzer(input);
            semanticTextBox.Text = semanticAnalysis;

            // Code Optimization
            string optimizedCode = CodeOptimization(input);
            optimizedTextBox.Text = optimizedCode;

            // Code Generation
            string generatedCode = CodeGeneration(input);
            generatedCodeTextBox.Text = generatedCode;
        }

        private string Lexer(string input)
        {
            // Lexer for the given grammar
            string tokens = "";
            foreach (char c in input)
            {
                if (char.IsDigit(c))
                {
                    tokens += "number ";
                }
                else if (char.IsLetter(c))
                {
                    tokens += "id ";
                }
                else if (c == '=' || c == '+' || c == '-' || c == '*' || c == '(' || c == ')')
                {
                    tokens += $"{c} ";
                }
                else if (c == ' ' || c == '\t' || c == '\n')
                {
                    continue;  // Ignore spaces and newlines
                }
                else
                {
                    tokens += $"Invalid character: {c} ";
                    break;
                }
            }
            return tokens;
        }

        private TreeNode Parser(string input)
        {
            // Parse the input according to the grammar
            TreeNode root = new TreeNode("stmt");

            // Split input into tokens for parsing
            var tokens = input.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            int index = 0;

            // Parse the statement (stmt -> assign | print)
            if (tokens[index] == "print")
            {
                root.Nodes.Add(ParsePrint(tokens, ref index));
            }
            else
            {
                root.Nodes.Add(ParseAssign(tokens, ref index));
            }

            return root;
        }

        private TreeNode ParseAssign(string[] tokens, ref int index)
        {
            // assign -> id = expr
            TreeNode assignNode = new TreeNode("assign");
            assignNode.Nodes.Add(new TreeNode($"id: {tokens[index]}"));
            index++;  // Move past the id
            assignNode.Nodes.Add(new TreeNode("="));
            index++;  // Move past the '='
            assignNode.Nodes.Add(ParseExpr(tokens, ref index));
            return assignNode;
        }

        private TreeNode ParsePrint(string[] tokens, ref int index)
        {
            // print -> print expr
            TreeNode printNode = new TreeNode("print");
            index++;  // Move past "print"
            printNode.Nodes.Add(ParseExpr(tokens, ref index));
            return printNode;
        }

        private TreeNode ParseExpr(string[] tokens, ref int index)
        {
            // expr -> term expr'
            TreeNode exprNode = new TreeNode("expr");
            exprNode.Nodes.Add(ParseTerm(tokens, ref index));
            exprNode.Nodes.Add(ParseExprPrime(tokens, ref index));
            return exprNode;
        }

        private TreeNode ParseExprPrime(string[] tokens, ref int index)
        {
            // expr' -> + term expr' | - term expr' | ε
            TreeNode exprPrimeNode = new TreeNode("expr'");
            if (index < tokens.Length && (tokens[index] == "+" || tokens[index] == "-"))
            {
                string operatorSymbol = tokens[index];
                exprPrimeNode.Nodes.Add(new TreeNode(operatorSymbol));
                index++;
                exprPrimeNode.Nodes.Add(ParseTerm(tokens, ref index));
                exprPrimeNode.Nodes.Add(ParseExprPrime(tokens, ref index));
            }
            return exprPrimeNode;
        }

        private TreeNode ParseTerm(string[] tokens, ref int index)
        {
            // term -> factor term'
            TreeNode termNode = new TreeNode("term");
            termNode.Nodes.Add(ParseFactor(tokens, ref index));
            termNode.Nodes.Add(ParseTermPrime(tokens, ref index));
            return termNode;
        }

        private TreeNode ParseTermPrime(string[] tokens, ref int index)
        {
            // term' -> * factor term' | ε
            TreeNode termPrimeNode = new TreeNode("term'");
            if (index < tokens.Length && tokens[index] == "*")
            {
                termPrimeNode.Nodes.Add(new TreeNode("*"));
                index++;
                termPrimeNode.Nodes.Add(ParseFactor(tokens, ref index));
                termPrimeNode.Nodes.Add(ParseTermPrime(tokens, ref index));
            }
            return termPrimeNode;
        }

        private TreeNode ParseFactor(string[] tokens, ref int index)
        {
            // factor -> (expr) | number | id
            TreeNode factorNode = new TreeNode("factor");
            if (tokens[index] == "(")
            {
                factorNode.Nodes.Add(new TreeNode("("));
                index++;
                factorNode.Nodes.Add(ParseExpr(tokens, ref index));
                if (tokens[index] == ")")
                {
                    factorNode.Nodes.Add(new TreeNode(")"));
                    index++;
                }
            }
            else if (tokens[index] == "id" || char.IsLetter(tokens[index][0]))
            {
                factorNode.Nodes.Add(new TreeNode($"id: {tokens[index]}"));
                index++;
            }
            else if (char.IsDigit(tokens[index][0]))
            {
                factorNode.Nodes.Add(new TreeNode($"number: {tokens[index]}"));
                index++;
            }
            return factorNode;
        }

        private string SemanticAnalyzer(string input)
        {
            // Simple semantic check: balanced parentheses
            int openParenthesesCount = 0;
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] == '(')
                {
                    openParenthesesCount++;
                }
                else if (input[i] == ')')
                {
                    openParenthesesCount--;
                }
            }

            if (openParenthesesCount != 0)
            {
                return "Semantic Error: Unmatched parentheses.";
            }

            return "Semantic Analysis: Input is valid.";
        }

        private string CodeOptimization(string input)
        {
            // Simple optimization: Remove redundant operations and simplify constants.
            string optimizedInput = input;

            // Replace redundant operations like *1, +0, -0.
            optimizedInput = optimizedInput.Replace(" * 1", "").Replace(" + 0", "").Replace(" - 0", "");

            // Simplify constant expressions (basic implementation for demonstration).
            string[] tokens = optimizedInput.Split(' ');
            for (int i = 0; i < tokens.Length - 2; i++)
            {
                if (int.TryParse(tokens[i], out int num1) && 
                    (tokens[i + 1] == "+" || tokens[i + 1] == "-") && 
                    int.TryParse(tokens[i + 2], out int num2))
                {
                    int result = tokens[i + 1] == "+" ? num1 + num2 : num1 - num2;
                    tokens[i] = result.ToString();
                    tokens[i + 1] = tokens[i + 2] = ""; // Mark as processed
                }
            }

            optimizedInput = string.Join(" ", tokens).Replace("  ", " ").Trim();
            return $"Code Optimization: {optimizedInput}";
        }

        private string CodeGeneration(string input)
        {
            // Generate assembly code for the input statement.
            string[] tokens = input.Split(' ');
            string assemblyCode = "";
            Stack<string> stack = new Stack<string>();

            for (int i = 0; i < tokens.Length; i++)
            {
                if (tokens[i] == "=")
                {
                    // Assignment: pop from stack and assign to id.
                    string id = tokens[i - 1];
                    assemblyCode += $"POP AX\nMOV {id}, AX\n";
                }
                else if (tokens[i] == "print")
                {
                    // Print: pop the top of stack and output.
                    assemblyCode += $"POP AX\nOUT AX\n";
                }
                else if (tokens[i] == "+" || tokens[i] == "-" || tokens[i] == "*")
                {
                    // Arithmetic operation: pop two values, perform operation, and push result back.
                    assemblyCode += "POP BX\nPOP AX\n";
                    if (tokens[i] == "+")
                        assemblyCode += "ADD AX, BX\n";
                    else if (tokens[i] == "-")
                        assemblyCode += "SUB AX, BX\n";
                    else if (tokens[i] == "*")
                        assemblyCode += "MUL BX\n";
                    assemblyCode += "PUSH AX\n";
                }
                else if (int.TryParse(tokens[i], out _) || char.IsLetter(tokens[i][0]))
                {
                    // Operand (number or id): push onto the stack.
                    assemblyCode += $"PUSH {tokens[i]}\n";
                }
            }

            return $"Generated Assembly Code:\n{assemblyCode}";
        }

    }
}
